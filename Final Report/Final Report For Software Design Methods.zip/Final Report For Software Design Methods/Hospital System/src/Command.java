
public interface Command {
	public String getDescription();

	public void execute();
}
