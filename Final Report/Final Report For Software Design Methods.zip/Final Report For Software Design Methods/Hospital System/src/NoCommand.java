
public class NoCommand implements Command {
	public String getDescription() {
		return "";
	}

	public void execute() {
	}
}
