
public class Doctor {
	String name;
	String doctorId;
	int age;
	String gender;
	String address;
	String contactNumber;
	String password;
	String department;

	public Doctor(String name, String doctorId, int age, String gender, String address, String contactNumber,
			String password, String department) {
		this.name = name;
		this.doctorId = doctorId;
		this.age = age;
		this.gender = gender;
		this.address = address;
		this.contactNumber = contactNumber;
		this.password = password;
		this.department = department;
	}

}
